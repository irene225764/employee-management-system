# Employee App Backend Integration

## Setup
1. Install Node.js.
2. Open this folder in VS Code / terminal.
3. Run `npm install`.
4. In MongoDB Atlas, create a database and allow your IP address in Network Access.
5. Set the environment variable `MONGODB_URI` to your Atlas connection string. The database name should be included in the URI, for example:
   `mongodb+srv://<username>:<password>@<cluster-url>/employeeapp?retryWrites=true&w=majority`
   Do not commit your real connection string or password to GitHub.
6. Run `npm start`.
7. Open `http://localhost:3000`.

The backend uses the `employeelist` collection and the fields `name`, `location`, `position`, and `salary`.

## API routes
- `GET /api/employeelist`
- `GET /api/employeelist/:id`
- `POST /api/employeelist` with JSON `{ "name": "...", "location": "...", "position": "...", "salary": 50000 }`
- `PUT /api/employeelist` with JSON containing `_id` (or `id`) plus fields to update
- `DELETE /api/employeelist/:id`

Check that the frontend uses these routes and field names before submission. Keep the supplied `dist` files unchanged.
